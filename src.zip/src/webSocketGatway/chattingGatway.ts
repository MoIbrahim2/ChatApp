import { Req, UseGuards } from '@nestjs/common';
import {
  ConnectedSocket,
  MessageBody,
  SubscribeMessage,
  WebSocketGateway,
  WebSocketServer,
  WsResponse,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { AuthWebSocketGuard } from 'src/auth/guards/websocket.guard';
import { ChatService } from 'src/chat/services/chat/chat.service';
import { MessageService } from 'src/message/services/message/message.service';
@UseGuards()
@WebSocketGateway(3002, { cors: '*' })
export class ChattingGatway {
  constructor(
    private chatService: ChatService,
    private messageService: MessageService,
  ) {}
  @WebSocketServer() server: Server;

  private sockets = new Map<string, string>();

  handleDisconnect(@ConnectedSocket() client) {
    console.log(`Client disconnected: ${client.id}`);
  }
  @UseGuards(AuthWebSocketGuard)
  @SubscribeMessage('on-connect')
  async onConnection(@ConnectedSocket() socket: Socket) {
    const user = socket['user'];
    console.log('client connected');
    if (user) this.sockets.set(user.id, socket.id);
    else {
      this.server
        .to(socket.id)
        .emit('error-event', 'Error detected disconnecting...');
      socket.disconnect();
    }
  }
  @UseGuards(AuthWebSocketGuard)
  @SubscribeMessage('send-message')
  async handleMessage(
    @ConnectedSocket() client: Socket,
    @MessageBody()
    payload: { receiverId: string; content: string },
  ) {
    const { receiverId, content } = payload;
    const user = client['user'];
    let chat = await this.chatService.findChat(user.id, receiverId);
    if (!chat) {
      chat = await this.chatService.createChat(user.id, receiverId);
    }
    await this.messageService.createMessage(chat.id, user.id, content);
    const senderSocket = this.sockets.get(user.id);
    const receiverSocket = this.sockets.get(receiverId);

    this.server.to(senderSocket).emit('new-message', content);
    this.server.to(receiverSocket).emit('new-message', content);
  }
}
