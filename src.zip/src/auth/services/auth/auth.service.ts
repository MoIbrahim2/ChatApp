import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { InjectRepository } from '@nestjs/typeorm';
import { Response } from 'express';
import { CreateUserDTO } from 'src/DTOs/createUserDTO.dto';
import { User } from 'src/entities/User';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User) private userRepository: Repository<User>,
    private jwtService: JwtService,
  ) {}
  async signup(createUserData: CreateUserDTO) {
    try {
      const user = this.userRepository.create(createUserData);
      const newUser = await this.userRepository.save(user);

      if (!newUser)
        throw new HttpException("Can't create user", HttpStatus.BAD_REQUEST);

      const token = await this.jwtService.signAsync({
        userId: newUser.id,
      });

      const { password, ...docWithoutPassword } = newUser;

      return {
        status: 'sucess',
        message: 'successfully created',
        data: { token, ...docWithoutPassword },
      };
    } catch (err) {
      err.status = err.status ? err.status : 500;
      return {
        status: 'fail',
        message: err.message,
      };
    }
  }

  async login(email: string, password: string) {
    try {
      const user = await this.userRepository.findOne({
        where: { email },
        select: ['id', 'password'],
      });

      if (!user || !(await bcrypt.compare(password, user.password))) {
        throw new HttpException(
          'Invalid email or Wrong password',
          HttpStatus.UNAUTHORIZED,
        );
      }
      const token = await this.jwtService.signAsync({
        userId: user.id,
      });

      return {
        status: 'success',
        token,
      };
    } catch (err) {
      err.status = err.status ? err.status : 500;
      return {
        status: 'fail',
        message: err.message,
      };
    }
  }
}
