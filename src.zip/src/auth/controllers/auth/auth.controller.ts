import {
  Body,
  Controller,
  Post,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { AuthService } from 'src/auth/services/auth/auth.service';
import { CreateUserDTO } from 'src/DTOs/createUserDTO.dto';
import { LoginUserDto } from 'src/DTOs/loginUserDto.dto';
@UsePipes(ValidationPipe)
@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}
  @Post('signup')
  async signup(@Body() userData: CreateUserDTO) {
    return await this.authService.signup(userData);
  }
  @Post('login')
  async login(@Body() userData: LoginUserDto) {
    return await this.authService.login(userData.email, userData.password);
  }
}
