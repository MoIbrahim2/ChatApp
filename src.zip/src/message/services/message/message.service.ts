import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Message } from 'src/entities/Message';
import { Repository } from 'typeorm';

@Injectable()
export class MessageService {
  constructor(
    @InjectRepository(Message) private messageRepository: Repository<Message>,
  ) {}
  async createMessage(chatId: string, userId: string, content: string) {
    const message = this.messageRepository.create({
      chat: { id: chatId },
      sender: { id: userId },
      content,
    });
    await this.messageRepository.save(message);
  }
  async findMessagesForUser(chatId: string, userId: string) {
    const messages = await this.messageRepository.find({
      where: { chat: { id: chatId }, sender: { id: userId } },
      select: ['content'],
    });
    if (!messages)
      throw new HttpException(
        'There is not messages for that user for specific chat',
        HttpStatus.NOT_FOUND,
      );
    return messages;
  }
}
