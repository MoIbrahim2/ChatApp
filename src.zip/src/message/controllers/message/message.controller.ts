import { Controller, Get, Param } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Message } from 'src/entities/Message';
import { MessageService } from 'src/message/services/message/message.service';
import { Repository } from 'typeorm';

@Controller('message')
export class MessageController {
  constructor(private messageService: MessageService) {}
  @Get(':chatId/:userId')
  async getMessagesForUser(
    @Param('chatId') chatId: string,
    @Param('userId') userId: string,
  ) {
    return await this.messageService.findMessagesForUser(chatId, userId);
  }
}
