import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './entities/User';
import { Message } from './entities/Message';
import { Chat } from './entities/Chat';
import { ChatModule } from './chat/chat.module';
import { MessageModule } from './message/message.module';
import { ChattingGatway } from './webSocketGatway/chattingGatway';
import { AuthModule } from './auth/auth.module';
import { JwtModule } from '@nestjs/jwt';
import { UserSubscriber } from './user/subscribers/userSubscriber';

@Module({
  imports: [
    JwtModule.register({
      secret: 'this-is-my-secret',
      signOptions: { expiresIn: '9d' },
    }),
    TypeOrmModule.forRoot({
      type: 'mysql',
      host: 'localhost',
      port: 3306,
      username: 'root',
      password: 'Zezo1234_',
      database: 'socketChatting',
      subscribers: [UserSubscriber],
      entities: [User, Message, Chat],
      // synchronize: true,
    }),
    TypeOrmModule.forFeature([User]),
    UserModule,
    ChatModule,
    MessageModule,
    AuthModule,
  ],
  controllers: [AppController],
  providers: [AppService, ChattingGatway],
})
export class AppModule {}
