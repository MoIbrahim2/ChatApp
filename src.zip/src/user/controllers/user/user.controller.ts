import {
  Body,
  Controller,
  Get,
  Post,
  UseGuards,
  UsePipes,
  ValidationPipe,
} from '@nestjs/common';
import { AuthGuard } from 'src/auth/guards/auth/auth.guard';
import { CreateUserDTO } from 'src/DTOs/createUserDTO.dto';
import { UserService } from 'src/user/services/user/user.service';
@UsePipes(ValidationPipe)
@Controller('user')
export class UserController {
  constructor(private userService: UserService) {}
  @UseGuards(AuthGuard)
  @Get('test1')
  async test() {
    return { message: 'This route is protected successfully' };
  }
}
