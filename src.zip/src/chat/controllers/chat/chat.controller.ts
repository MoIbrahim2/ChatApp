import { Controller, Get, Param, Post } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { ChatService } from 'src/chat/services/chat/chat.service';
import { Chat } from 'src/entities/Chat';
import { User } from 'src/entities/User';
import { Repository } from 'typeorm';

@Controller('chat')
export class ChatController {
  constructor(private chatService: ChatService) {}
  @Post('create/:id1/:id2')
  async createChat(@Param('id1') id1: string, @Param('id2') id2: string) {
    return await this.chatService.createChat(id1, id2);
  }
  @Get('find/:id1/:id2')
  async findChat(@Param('id1') id1: string, @Param('id2') id2: string) {
    return await this.chatService.findChat(id1, id2);
  }
}
